//
//  Suit.m
//  Assignment 3
//
//  Created by John Chen on 3/8/15.
//  Copyright (c) 2015 John Chen. All rights reserved.
//

#import "Suit.h"

@implementation Suit

@end
